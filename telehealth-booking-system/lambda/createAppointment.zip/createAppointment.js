const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  const { appointmentId, patientName, appointmentTime } = JSON.parse(event.body);

  const params = {
    TableName: 'Appointments',
    Item: {
      AppointmentID: appointmentId,
      PatientName: patientName,
      AppointmentTime: appointmentTime,
    },
  };

  try {
    await dynamoDb.put(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Appointment created successfully!' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Could not create appointment' }),
    };
  }
};
