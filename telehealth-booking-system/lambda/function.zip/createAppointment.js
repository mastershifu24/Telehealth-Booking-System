const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  console.log('Full Event:', JSON.stringify(event, null, 2)); // Log the entire event
  console.log('Event body:', event.body); // Log the event body
  
  let body;
  try {
    if (typeof event.body === 'string') {
      body = JSON.parse(event.body); 
    } else {
      throw new Error('Invalid event body: not a string');
    }
  } catch (e) {
    console.error('Error parsing event body:', e.message); // Log the error
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Invalid JSON format" }),
    };
  }

  const { patientName, appointmentTime } = body;

  const params = {
    TableName: 'Appointments',
    Item: {
      AppointmentID: `${patientName}-${appointmentTime}`, 
      PatientName: patientName,
      AppointmentTime: appointmentTime,
    },
  };

  try {
    await dynamo.put(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Appointment created successfully" }),
    };
  } catch (error) {
    console.error('Error saving to DynamoDB:', error.message); // Log the error
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Could not create appointment" }),
    };
  }
};
